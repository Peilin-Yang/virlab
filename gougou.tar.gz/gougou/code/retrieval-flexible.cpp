#include "query.hpp"
#include <iostream>
#include <math.h>
#include "IndexReaderBase.hpp"
#include "MinHeap.hpp"
#include <string>
#include <fstream>
#include "TimeCounter.hpp"
#include <stdlib.h>
#include <dlfcn.h>
#include <sstream>

using namespace std;

#define MaxNum 0xFFFFFFFF

int RetNum=1000;

struct termReter
{
	unsigned curDocID;
	PostingListReader *PR;
	unsigned termID;
	float QF;
	float maxScore;
};

typedef float (*grade_T)(float tf[],float docLength);

class RetManager
{
public:
	RetManager(IndexReaderBase *IR,query *q);
	void retrieval(unsigned retNum);
	void show(ostream& FO);
  bool GenerateLinkFile(char* input,char* output);
  bool setLinkFile(string s);
  virtual float grade();
	virtual ~RetManager();
private:
	IndexReaderBase *theIndex;
	unsigned num;
	string topicNum;

	termReter *r;
	
	unsigned* retDocID;
	float* retDocScore;
	unsigned retN;
	unsigned curDoc;
	MinHeap* topDocs;

  string linkFile;
  grade_T gradeFun;
  void* handle;
  unsigned maxDF;

	inline unsigned findNextDoc();
  string replaceGradeString(string,unsigned i);
  string replaceGradeFunction(string);
};

RetManager::RetManager(IndexReaderBase *IR,query *q)
{
	unsigned i;
	theIndex = IR;
	num = 0;
	topicNum = q->topicNum;
	// Initial arrays
	r = new termReter[q->term.size()];
	// set initial values
	for(i=0;i<q->term.size();i++)
	{
    r[num].termID = theIndex->TermLookup(q->term[i]);
    if (r[num].termID!=0) {
      r[num].PR = theIndex->GetPosting(r[num].termID);
      if (r[num].PR!=NULL) {
        if (r[num].PR->NextDoc()) {
          r[num].curDocID = r[num].PR->CurDocID();
          r[num].QF = q->tf[i];
          num++;
        } else {
          delete r[num].PR;
        }
      } else {
        cout<<"Could not open the posting list of term "<<r[num].termID<<endl;
      }
    } else {
      cout<<"Could not find the term "<<q->term[i]<<endl;
    }
  }
	// set other values
	retDocID = NULL;
	retDocScore = NULL;
	retN = 0;
	curDoc = 0;
	topDocs = NULL;
  maxDF = 0;
}

RetManager::~RetManager()
{
	unsigned i;
	for(i=0;i<num;i++) if(r[i].PR!=NULL) delete r[i].PR;
	delete[] r;
	if(retDocID != NULL) delete[] retDocID;
	if(retDocScore!=NULL) delete[] retDocScore;
  if(handle!=NULL)
  {
    std::string com="rm "+linkFile;
    system(com.c_str());
    dlclose(handle);
  }
}

void RetManager::retrieval(unsigned retNum)
{
	retDocID = new unsigned[retNum];
	retDocScore = new float[retNum];
	topDocs = new MinHeap(retNum);
	
	while((curDoc = findNextDoc())!=MaxNum)
	{
    //float score = 0;
		float score = grade();
		if(score > topDocs->smallest) topDocs->push(curDoc,score);
	}
	retN = topDocs->n;
	int i;
	for(i=retN-1;i>=0;i--)
	{
		retDocID[i] = topDocs->pop(retDocScore[i]);
	}
	delete(topDocs);
}

void RetManager::show(ostream &OF)
{
	unsigned i;
	for(i=0;i<retN;i++)
	{
		OF<<topicNum<<"\t";
		OF<<theIndex->DocName(retDocID[i])<<"\t";
		//OF<<retDocID[i]<<"\t";
		OF<<retDocScore[i]<<endl;
	}
}

unsigned inline RetManager::findNextDoc()
{
	unsigned minDoc = MaxNum;
	unsigned i,l;
	float s=0.0f;

	for(i=0;i<num;i++)
	{
		if(r[i].curDocID<=curDoc) 
		{
			if(r[i].PR->NextDoc()) r[i].curDocID = r[i].PR->CurDocID();
			else r[i].curDocID = MaxNum;
		}
	}
	for(i=0;i<num;i++)
	{
		if(minDoc> r[i].curDocID) minDoc = r[i].curDocID;
	}
	return minDoc;
}

float inline RetManager::grade()
{
	/*const float okapiK1 = 1.2;
	const float  okapiK3 = 7;
	float score = 0;
	float docN = theIndex -> DocCount();
	float docLength = theIndex -> DocLength(curDoc);
	//float docLength = 100;
	float docLengthAvg = theIndex -> DocLengthAvg();
	unsigned i;
	for(i=0;i<num;i++)
	{
		if(curDoc == r[i].curDocID)
		{
			float DF = r[i].PR->GetSummary().df;
			float tf = r[i].PR->CurTF();
			float idf = log((docN-DF+0.5)/(DF+0.5));
			//float idf = log((1.0+docN)/DF);
			//float weight = (1.0+log(1+log(tf)))/(1.0-okapiB+okapiB*docLength/docLengthAvg);
			float weight = ((okapiK1+1.0)*tf) / (okapiK1*(1.0-okapiB+okapiB*docLength/docLengthAvg)+tf);
			float tWeight = ((okapiK3+1)*r[i].QF)/(okapiK3+r[i].QF);
			score+=idf*weight*tWeight;
			//if(curDoc == 525647) cout<<"i="<<i<<":"<<tf<<endl;
			//score+=idf*weight;
		}
	}*/

  float tf[num];
  float docLength = theIndex->DocLength(curDoc);
  for(unsigned i=0;i<num;i++) {
    if(curDoc == r[i].curDocID) tf[i] = r[i].PR->CurTF();
    else tf[i]=0;
  }
  float score=gradeFun(tf,docLength);
  return score;
}

bool RetManager::GenerateLinkFile(char* input,char* output)
{
  ifstream F1;
  ofstream F2;
  char outputFile[256];
  char soFile[256];
  strcpy(outputFile,output);
  strcpy(soFile,output);
  strcat(outputFile,".cpp");
  strcat(soFile,".so");
  F1.open(input);
  if(!F1.is_open()) {std::cout<<"could not read the file "<<input<<std::endl;return false;}
  std::string s,line;
  while(!F1.eof())
  {
    std::getline(F1,line);
    s+=line+'\n';
  }
  F1.close();
  s=replaceGradeFunction(s);

// without template design below
  F2.open(outputFile);
  if(!F2.is_open()) {std::cout<<"could not write to the file "<<outputFile<<std::endl;return false;}
  F2<<"#include <math.h>"<<std::endl<<std::endl;
  F2<<"extern \"C\" float gradeDoc(float tf[],float docLength)"<<std::endl;
  F2<<"{"<<std::endl;
  F2<<"\tfloat score=0;"<<std::endl;
  F2<<"//core code is below\n";
  F2<<s;
  F2<<"//core code is above\n";
  F2<<"\treturn score;\n";
  F2<<"}\n";
  F2.close();
// without template design above

  FILE *fp;
  char com[2048]="g++ -fPIC -shared";
  char buf[2048];
  strcat(com," ");
  strcat(com,outputFile);
  strcat(com," -o ");
  strcat(com,soFile);
  bool mark=true;
  if((fp=popen(com,"r"))==NULL) { std::cerr<<"Could not excute "<<com<<std::endl;return false;}
  while(fgets(buf,2048,fp)!=NULL) {std::cout<<buf;mark=false;}
  //std::cout<<std::endl;
  pclose(fp);
  std::string so=soFile;
  if(!setLinkFile(so)) {std::cerr<<"link file fails "<<std::endl;mark=false;}
  return mark;
}

std::string RetManager::replaceGradeFunction(std::string s)
{
  int b=0,p=0,n=0;
  int bn;
  bool mark;
  unsigned i;
  std::string code,subS;
  while(1)
  {
    p=s.find("if(occur)",b);
    n=s.find("for(occur)",b);
    if(p==std::string::npos || (n!=std::string::npos && n<p)) p=n;
    n=s.find("for(all)",b);
    if(p==std::string::npos || (n!=std::string::npos && n<p)) p=n;
    if(p==std::string::npos) break;
    subS=s.substr(b,p-b);
    code+=replaceGradeString(subS,0);
    mark=(p!=n);
    n=p;
    bn=0;
    while(n<s.size())
    {
      if(s[n]=='{')
      {
        if(bn==0) b=n;
        bn++;
      }
      else if(s[n]=='}')
      {
        bn--;
        if(bn<0) {std::cerr<<"incorrect retrieval function at "<<n<<" of "<<s<<std::endl;return "";}
        if(bn==0) {p=n;break;}
      }
      n++;
    }
    if(n>=s.size()) {std::cerr<<"incorrect retrieval function at "<<s<<std::endl;return "";}
    subS=s.substr(b,p-b+1);
    for(i=0;i<num;i++)
    {
      if(mark)
      {
        std::ostringstream strs;
        strs << "if(tf["<<i<<"]>0)";
        code+=strs.str()+"\n";
      }
      else
      {
        std::ostringstream strs;
        strs << "// iteration for term "<< i;
        code+=strs.str()+"\n";
      }
      code+=replaceGradeString(subS,i);
    }
    b=p+1;
  }
  subS=s.substr(b);
  code+=replaceGradeString(subS,0);
  return code;
}

std::string RetManager::replaceGradeString(std::string s,unsigned i)
{
    std::string subS=s;
    int pos=0;
    while((pos=subS.find("docN",pos))!=std::string::npos)
    {
      std::ostringstream strs;
      strs << theIndex->DocCount();
      std::string str = strs.str();
      subS.replace(pos,strlen("docN"),str);
    }
    pos=0;
    while((pos=subS.find("termN",pos))!=std::string::npos)
    {
      std::ostringstream strs;
      strs << theIndex->TermCount();
      std::string str = strs.str();
      subS.replace(pos,strlen("termN"),str);
    }
    pos=0;
    while((pos=subS.find("collectionN",pos))!=std::string::npos)
    {
      std::ostringstream strs;
      strs << theIndex->TotalTermCount();
      std::string str = strs.str();
      subS.replace(pos,strlen("collectionN"),str);
    }
    pos=0;
    while((pos=subS.find("docLengthAvg",pos))!=std::string::npos) {
      std::ostringstream strs;
      strs << (float)theIndex->TotalTermCount()/theIndex->DocCount();
      std::string str = strs.str();
      subS.replace(pos,strlen("docLengthAvg"),str);
    }
    pos=0;
    while((pos=subS.find("MaxDF",pos))!=std::string::npos)
    {
      std::ostringstream strs;
      if(maxDF==0)
      {
        unsigned DF;
        unsigned i;
        for(i=1;i<=theIndex->TermCount();i++)
        {
          PostingListReader* PLR = theIndex->GetPosting(i);
          if((DF=PLR->GetSummary().df)>maxDF) maxDF=DF;
          delete PLR;
        }
      }
      strs << maxDF;
      std::string str = strs.str();
      subS.replace(pos,strlen("MaxDF"),str);
    }
    pos=0;
    while((pos=subS.find("queryLength",pos))!=std::string::npos)
    {
      std::ostringstream strs;
      float QL=0;
      for(i=0;i<num;i++)
      {
        QL+=r[i].QF;
      }
      strs << QL;
      std::string str = strs.str();
      subS.replace(pos,strlen("queryLength"),str);
    }
    pos=0;
    while((pos=subS.find("DF[i]",pos))!=std::string::npos)
    {
      std::ostringstream strs;
      strs << r[i].PR->GetSummary().df;
      std::string str = strs.str();
      subS.replace(pos,strlen("DF[i]"),str);
    }
    pos=0;
    while((pos=subS.find("tf[i]",pos))!=std::string::npos)
    {
      std::ostringstream strs;
      strs << "tf["<<i<<"]";
      std::string str = strs.str();
      subS.replace(pos,strlen("tf[i]"),str);
    }
    pos=0;
    while((pos=subS.find("termPro[i]",pos))!=std::string::npos)
    {
      std::ostringstream strs;
      strs << (float)r[i].PR->GetSummary().tf/theIndex->TotalTermCount();
      std::string str = strs.str();
      subS.replace(pos,strlen("termPro[i]"),str);
    }
    pos=0;
    while((pos=subS.find("qf[i]",pos))!=std::string::npos)
    {
      std::ostringstream strs;
      strs << r[i].QF;
      std::string str = strs.str();
      subS.replace(pos,strlen("qf[i]"),str);
    }
    pos=0;
    while((pos=subS.find("TFC[i]",pos))!=std::string::npos)
    {
      std::ostringstream strs;
      strs << r[i].PR->GetSummary().tf;
      std::string str = strs.str();
      subS.replace(pos,strlen("TFC[i]"),str);
    }

  return subS;
}

bool RetManager::setLinkFile(std::string s)
{
  linkFile="./"+s;
  handle = dlopen(linkFile.c_str(), RTLD_LAZY);
  //void* handle = dlopen("./okapi2.so",RTLD_LAZY);
  if(!handle) {std::cerr<<"could not open link file "<<linkFile<<std::endl;return false;}
  gradeFun = (grade_T) dlsym(handle, "gradeDoc");
  return true;
}
	
void retrieval(char *indexPath,queryManager *queries,char *outputFile,char *retFun)
{
	IndexReaderBase *theIndex = new IndexReaderBase(indexPath);
	//char blockInfoName[] = "BM25-02";
	//theIndex -> loadBlockInfo(blockInfoName);
	
	ofstream F1;
	F1.open(outputFile);
	if(!F1) {cerr << "Error: file "<<outputFile<<" Could not be writ to"<<endl; return;}
	
	unsigned i;
	for(i=0;i<queries->num();i++)
	{
		query* qry = queries -> getQuery(i);
		RetManager *reter = new RetManager(theIndex,qry);
    char gOutput[2048];
    strcpy(gOutput,retFun);
    strcat(gOutput,"-link-");
    strcat(gOutput,qry->term[0].c_str());
    reter->GenerateLinkFile(retFun,gOutput);
		reter->retrieval(RetNum);
		reter->show(F1);
		cout<<"\r retrieval topic "<<qry->topicNum<<flush;
    char com[2048];
    strcpy(com,"rm ");
    strcat(com,gOutput);
    strcat(com,".cpp");
    system(com);
		delete reter;
	}
	cout<<endl;
	F1.close();
	delete(theIndex);
}

int main(int argc,char **argv)
{
	if(argc!=5 && argc!=6) { cout<<"Usage: "<<argv[0]<<" indexPath qry outputFile retFun (retNum)"<<endl; return 0;}
	if(argc==6) RetNum=atoi(argv[5]);
	queryManager *queries = new queryManager(argv[2]);
	queries->show();
	retrieval(argv[1],queries,argv[3],argv[4]);
	delete queries;
	return 0;
}

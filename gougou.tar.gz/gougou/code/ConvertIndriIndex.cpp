#include <iostream>
#include "IndriIndexConverter.hpp"

using namespace std;

int main(int argc, char** argv) {
  if (argc!=3) { cerr<<"Usage: "<<argv[0]<<" indriIndex newIndex"<<endl; return 0;}
  IndriIndexConverter* converter = new IndriIndexConverter(argv[1], argv[2]);
  converter->BuildIndex();
  delete converter;
  return 0;
}

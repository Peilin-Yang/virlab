#include "IndriInvertConverter.hpp"

#include "indri/Repository.hpp"
#include "indri/LocalQueryServer.hpp"
#include "indri/ScopedLock.hpp"
#include <math.h>
#include <vector>

#include <stdint.h>
#include "DAM.hpp"
#include "TermMeta.hpp"
#include "TermSummaryForInvert.hpp"
#include "PForCompressor.hpp"

using namespace std;

IndriInvertConverter::IndriInvertConverter(indri::index::Index* theIndex, char* term_path, char* invert_path) {
  indri_index_ = theIndex;
  invert_DAM_ = new DiskAsMemory(invert_path, sizeof(unsigned), 4096);
  term_DAM_ = new DiskAsMemory(term_path, sizeof(TermSummaryForInvert), 1024);
  compressor_ = new PForCompressor();
}

void IndriInvertConverter::BuildIndex() {
  DiskItem* DI = term_DAM_->addNewItem();
  TermSummaryForInvert* total_summary = (TermSummaryForInvert*)DI->content;
  total_summary->tf = indri_index_->termCount();
  total_summary->df = indri_index_->uniqueTermCount();
  total_summary->block_num = 0;
  total_summary->address = 0;
  total_summary->data_length = 0;
  delete DI;
  cout<<"OK"<<endl;
  for (unsigned i=1; i <= indri_index_->uniqueTermCount(); i++) {
    if (i%100==0) cout<<"\rProcess Term "<<i<<" of "<<indri_index_->uniqueTermCount()<<flush;
    ConvertIndex(i);
  }
  cout<<endl;
} 

IndriInvertConverter::~IndriInvertConverter() {
  delete invert_DAM_;
  delete term_DAM_;
  delete compressor_;
}

void IndriInvertConverter::ConvertIndex(unsigned termID) {
  vector<unsigned> TFs;
  vector<unsigned> docIDs;
  unsigned curDoc = 0;

  unsigned df = indri_index_->documentCount(indri_index_->term(termID));
  unsigned block_num = (df + COMPRESS_BLOCK_SIZE - 1) / COMPRESS_BLOCK_SIZE;

  DiskItem* DI = term_DAM_->addNewItem();
  TermSummaryForInvert* summary = (TermSummaryForInvert*)DI->content;
  summary->tf = indri_index_->termCount(indri_index_->term(termID));
  summary->df = df;
  summary->block_num = block_num;
  summary->address = invert_DAM_->getItemCounter();

  if (df == 0) {
    cerr<<"Empty Posting list of "<<termID<<endl;
    delete DI;
    return;
  }

  DiskMultiItem* items = invert_DAM_->AddMultiNewItem(block_num*sizeof(BlockSummaryForInvert)/sizeof(unsigned));
  unsigned summary_offset = 0; 
  
  // Initial indri index read
  indri::index::DocListIterator* diList = indri_index_->docListIterator(termID);
  if (diList == NULL) {
    cerr<<"Cannot read the Indri Index of term "<<termID<<endl;
  } else {
    diList->startIteration();
    unsigned posting_counter = 0;
    do {
      indri::index::DocListIterator::DocumentData *diEntry = diList->currentEntry();
      if (docIDs.empty()) curDoc = diEntry->document;
      TFs.push_back(diEntry->positions.size());
      docIDs.push_back(diEntry->document);
      diList->nextEntry();
      if (docIDs.size() >= COMPRESS_BLOCK_SIZE || diList->currentEntry() == NULL) {
        posting_counter++;
        PForBlock docIDBlock = CompressDocID(docIDs,curDoc);
        PForBlock TFBlock = CompressTF(TFs);
        TFs.clear();
        docIDs.clear();
        BlockSummaryForInvert block_summary;
        block_summary.a1 = docIDBlock.a & 7;
        block_summary.b1 = docIDBlock.b & 31;
        block_summary.length1 = docIDBlock.data.size();
        block_summary.a2 = TFBlock.a & 7;
        block_summary.b2 = TFBlock.b & 31;
        block_summary.length2 = TFBlock.data.size();
        block_summary.docID = curDoc;
        items->MemcpyIn((char*)&block_summary, summary_offset, sizeof(BlockSummaryForInvert)/sizeof(unsigned));
        summary_offset += sizeof(BlockSummaryForInvert)/sizeof(unsigned);
        DiskMultiItem* dataItems = invert_DAM_->AddMultiNewItem(docIDBlock.data.size());
        dataItems->MemcpyIn((char*)&docIDBlock.data[0], 0, docIDBlock.data.size());
        delete dataItems;
        dataItems = invert_DAM_->AddMultiNewItem(TFBlock.data.size());
        dataItems->MemcpyIn((char*)&TFBlock.data[0], 0, TFBlock.data.size());
        delete dataItems;
      }
    } while (diList->currentEntry() != NULL);
    if (posting_counter != block_num) cout<<"The number does not match!"<<endl;
  }
  delete diList;
  delete items;

  summary->data_length = invert_DAM_->getItemCounter() - summary->address;
  delete DI;

} 

PForBlock IndriInvertConverter::CompressTF(const vector<unsigned>& tf) {
  vector<unsigned> temp;
  for (unsigned i=0;i<tf.size();i++) {
    temp.push_back(tf[i]-1);
  }
  return compressor_->compress(temp);
}

PForBlock IndriInvertConverter::CompressDocID(const vector<unsigned>& docID, unsigned cur_docID) {
  vector<unsigned> temp;
  temp.push_back(docID[0] - cur_docID);
  for (unsigned i=1; i<docID.size(); i++) {
    temp.push_back(docID[i] - docID[i-1] - 1);
  }
  return compressor_->compress(temp);
}

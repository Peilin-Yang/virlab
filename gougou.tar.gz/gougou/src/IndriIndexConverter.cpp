#include "IndriIndexConverter.hpp"

#include "IndriInvertConverter.hpp"
#include "IndexGlobalInfo.hpp"
#include "PrefixTree.hpp"

using namespace std;

IndriIndexConverter::IndriIndexConverter(char* indriPath, char* path) {
  indri_reaper_.openRead(indriPath);
  indri_collection_ = indri_reaper_.collection();
  indri::server::LocalQueryServer local(indri_reaper_);
  indri_index_ = (*(indri_reaper_.indexes()))[0];
  indri::thread::ScopedLock(indri_index_->iteratorLock());
  strcpy(path_,path);
}

IndriIndexConverter::~IndriIndexConverter() {
  indri_reaper_.close();
}

void IndriIndexConverter::BuildIndex() {
  mkdir(path_,S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
  char invert_summary_path[256];
  strcpy(invert_summary_path,path_);
  strcat(invert_summary_path,"/invert_summary");
  char invert_body_path[256];
  strcpy(invert_body_path,path_);
  strcat(invert_body_path,"/invert_body");
  //BuildInvertIndex(invert_summary_path, invert_body_path);

  char prefix_tree_temp_path[256];
  strcpy(prefix_tree_temp_path,path_);
  strcat(prefix_tree_temp_path,"/prefix_tree_temp");
  char prefix_tree_path[256];
  strcpy(prefix_tree_path,path_);
  strcat(prefix_tree_path,"/term_lookup");
  BuildTermLookup(prefix_tree_temp_path, prefix_tree_path);

  char term_name_path[256];
  strcpy(term_name_path,path_);
  strcat(term_name_path,"/term_name_lookup");
  //BuildTermNameLookup(term_name_path);

  char doc_name_path[256];
  strcpy(doc_name_path,path_);
  strcat(doc_name_path,"/doc_name_lookup");
  //BuildDocNameLookup(doc_name_path);

  char doc_index_path[256];
  strcpy(doc_index_path,path_);
  strcat(doc_index_path,"/doc_index");
  //BuildDocIndex(doc_index_path);

  char doc_length_path[256];
  strcpy(doc_length_path,path_);
  strcat(doc_length_path,"/doc_length");
  //BuildDocLength(doc_length_path);

  char global_path[256];
  strcpy(global_path,path_);
  strcat(global_path,"/global");
  //BuildGlobal(global_path);
}

void IndriIndexConverter::BuildInvertIndex(char* termPath, char* bodyPath) {
  IndriInvertConverter *converter = new IndriInvertConverter(indri_index_, termPath, bodyPath);
  converter->BuildIndex();
  delete converter;
}

void IndriIndexConverter::BuildTermLookup(char* tempPath, char* lookupPath) {
  PrefixTree* term_lookup = new PrefixTree();
  for(unsigned i=1; i<=indri_index_->uniqueTermCount(); i++) {
    if (indri_reaper_.processTerm(indri_index_->term(i)) != "") term_lookup->InsertTerm(indri_index_->term(i),i);
  }
  term_lookup->WriteToFile(lookupPath);
  delete term_lookup;
}

void IndriIndexConverter::BuildTermNameLookup(char* term_name_path) {
  NameLookup* term_name = new NameLookup(term_name_path);
  for (unsigned i=1; i<=indri_index_->uniqueTermCount(); i++) {
    term_name->AddItem(indri_index_->term(i), i);
  }
  delete term_name;
}

void IndriIndexConverter::BuildDocNameLookup(char* doc_name_path) {
  NameLookup* doc_name = new NameLookup(doc_name_path);
  for (unsigned i=1; i<=indri_index_->documentCount(); i++) {
    doc_name->AddItem(indri_collection_->retrieveMetadatum(i, "docno"), i);
  }
  delete doc_name;
}

void IndriIndexConverter::BuildDocIndex(char* doc_index_path) {
  VectorInfo* doc_index = new VectorInfo(doc_index_path);
  for (unsigned i=1; i<=indri_index_->documentCount(); i++) {
    vector<unsigned> doc_vector;
    const indri::index::TermList *termList = indri_index_->termList(i);
    for (unsigned l=0; l<termList->terms().size(); l++) {
      doc_vector.push_back(termList->terms()[l]);
    }
    doc_index->AddVector(doc_vector, i);
    delete termList;
  }
  delete doc_index;
}

void IndriIndexConverter::BuildDocLength(char* doc_length_path) {
  SimpleStatBuilder<unsigned>* doc_length = new SimpleStatBuilder<unsigned>(doc_length_path);
  doc_length->AddItem(0);
  for (unsigned i=1; i<=indri_index_->documentCount(); i++) {
    doc_length->AddItem(indri_index_->documentLength(i));
  }
  delete doc_length;
}

void IndriIndexConverter::BuildGlobal(char* global_path) {
  DiskAsMemory* DAM = new DiskAsMemory(global_path, sizeof(IndexGlobalInfo), 1024);
  DiskItem* item = DAM->addNewItem();
  IndexGlobalInfo* global = (IndexGlobalInfo*)item->content;
  global->docN = indri_index_->documentCount();
  global->termN = indri_index_->uniqueTermCount();
  global->totalTF = indri_index_->termCount();
  delete item;
  delete DAM;
}

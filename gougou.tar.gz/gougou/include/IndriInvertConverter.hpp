#ifndef GOUGOU_INDRI_INVERT_CONVERTER_
#define GOUGOU_INDRI_INVERT_CONVERTER_

#include "indri/Repository.hpp"
#include "indri/LocalQueryServer.hpp"
#include "indri/ScopedLock.hpp"
#include <math.h>

#include <stdint.h>
#include "DAM.hpp"
#include "PForCompressor.hpp"

using namespace std;

class IndriInvertConverter {
public:
  IndriInvertConverter(indri::index::Index* theIndex, char* term_path, char* invert_path);
  void BuildIndex();
  ~IndriInvertConverter();
protected:
  void ConvertIndex(unsigned termID);
  PForBlock CompressTF(const vector<unsigned>& tf);
  PForBlock CompressDocID(const vector<unsigned>& docID, unsigned curDoc);
private:
  indri::index::Index* indri_index_;
  DiskAsMemory* invert_DAM_;
  DiskAsMemory* term_DAM_;
  PForCompressor* compressor_;
};

#endif

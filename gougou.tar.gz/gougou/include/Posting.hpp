#ifndef GOUGOU_POSTING_
#define GOUGOU_POSTING_

using namespace std;

class Posting {
 public:
  unsigned docID;
  unsigned tf;
};

#endif

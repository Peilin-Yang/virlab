#ifndef GOUGOU_INDRI_INDEX_CONVERTER_
#define GOUGOU_INDRI_INDEX_CONVERTER_

#include "indri/Repository.hpp"
#include "indri/CompressedCollection.hpp"
#include "indri/LocalQueryServer.hpp"
#include "indri/ScopedLock.hpp"

#include "IndriInvertConverter.hpp"
#include "NameLookup.hpp"
#include "SimpleStatBuilder.hpp"
#include "TermMeta.hpp"
#include "VectorInfo.hpp"

using namespace std;

class IndriIndexConverter {
 public:
  IndriIndexConverter(char* indriPath, char* path);
  void BuildIndex();
  void BuildInvertIndex(char* termPath, char* bodyPath);
  void BuildTermLookup(char* tempPath, char* path);
  void BuildTermNameLookup(char* path);
  void BuildDocNameLookup(char* path);
  void BuildDocIndex(char* path);
  void BuildDocLength(char* path);
  void BuildGlobal(char* path);
  ~IndriIndexConverter();
 private:
  indri::collection::Repository indri_reaper_;
  indri::index::Index* indri_index_;
  indri::collection::CompressedCollection* indri_collection_;
  char path_[256];
};

#endif
  

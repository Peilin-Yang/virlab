#ifndef GOUGOU_INVERT_INDEX_META_
#define GOUGOU_INVERT_INDEX_META_

using namespace std;

struct InvertIndexMeta {
  unsigned tf;
  unsigned df;
  unsigned address;
  unsigned char high_address;
};

#endif
  
